from flask import Flask, render_template_string, request, redirect, url_for
import pandas as pd
from datetime import datetime

app = Flask(__name__)
EXCEL_PATH = "budget.xlsx"

категории_доход = {
    "Работа": ["Зарплата", "Фриланс", "Бонусы"],
    "Инвестиции": ["Дивиденды", "Проценты"],
    "Прочее": ["Подарки", "Возвраты"]
}

категории_расход = {
    "Еда": ["Продукты", "Кафе", "Фастфуд"],
    "Транспорт": ["Автобус", "Метро", "Такси"],
    "Коммунальные платежи": ["Интернет", "Электричество", "Вода"],
    "Развлечения": ["Кино", "Игры", "Подписки"]
}

def загрузить_данные():
    try:
        return pd.read_excel(EXCEL_PATH)
    except:
        return pd.DataFrame(columns=["Дата", "Тип", "Категория", "Подкатегория", "Сумма"])

def сохранить_запись(тип, категория, подкатегория, сумма):
    df = загрузить_данные()
    новая = {
        "Дата": datetime.today().strftime('%Y-%m-%d'),
        "Тип": тип,
        "Категория": категория,
        "Подкатегория": подкатегория,
        "Сумма": float(сумма)
    }
    df = pd.concat([df, pd.DataFrame([новая])], ignore_index=True)
    df.to_excel(EXCEL_PATH, index=False)

TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Учёт бюджета</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body style="font-family: sans-serif; max-width: 500px; margin: auto;">
    <h2>📊 Учёт доходов и расходов</h2>
    <form method="post">
        <label>Тип:</label><br>
        <select name="тип" onchange="this.form.submit()">
            <option value="Доход" {% if тип == 'Доход' %}selected{% endif %}>Доход</option>
            <option value="Расход" {% if тип == 'Расход' %}selected{% endif %}>Расход</option>
        </select><br><br>

        <label>Категория:</label><br>
        <select name="категория" onchange="this.form.submit()">
            {% for cat in категории %}
                <option value="{{ cat }}" {% if cat == категория %}selected{% endif %}>{{ cat }}</option>
            {% endfor %}
        </select><br><br>

        <label>Подкатегория:</label><br>
        <select name="подкатегория">
            {% for sub in подкатегории %}
                <option value="{{ sub }}">{{ sub }}</option>
            {% endfor %}
        </select><br><br>

        <label>Сумма:</label><br>
        <input type="number" step="0.01" name="сумма" required><br><br>

        <button type="submit">Сохранить</button>
    </form>

    <p><a href="/">Обновить</a></p>
</body>
</html>
'''

@app.route("/", methods=["GET", "POST"])
def home():
    тип = request.form.get("тип", "Доход")
    категория = request.form.get("категория", list((категории_доход if тип == "Доход" else категории_расход).keys())[0])
    подкатегории = (категории_доход if тип == "Доход" else категории_расход).get(категория, [])

    if request.method == "POST" and "сумма" in request.form:
        подкатегория = request.form.get("подкатегория")
        сумма = request.form.get("сумма")
        сохранить_запись(тип, категория, подкатегория, сумма)
        return redirect(url_for("home"))

    return render_template_string(TEMPLATE, тип=тип, категория=категория, категории=(категории_доход if тип == "Доход" else категории_расход).keys(), подкатегории=подкатегории)

if __name__ == "__main__":
    app.run(debug=True)
